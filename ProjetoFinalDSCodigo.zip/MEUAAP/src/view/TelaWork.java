package view;

public class TelaWork extends javax.swing.JFrame {

    public TelaWork() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnVoltarLogin = new javax.swing.JButton();
        btnGoAtualizar = new javax.swing.JButton();
        btnSaindoWork = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Workspace");
        setLocationByPlatform(true);
        setMaximumSize(new java.awt.Dimension(584, 584));
        setMinimumSize(new java.awt.Dimension(584, 584));
        setResizable(false);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        jPanel1.setBackground(new java.awt.Color(47, 46, 65));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Montserrat", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Workspace");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel2)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel1);
        jPanel1.setBounds(0, 0, 584, 114);

        jButton1.setBackground(new java.awt.Color(102, 51, 255));
        jButton1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Send E-mail");
        jPanel3.add(jButton1);
        jButton1.setBounds(240, 230, 154, 38);

        jLabel1.setFont(new java.awt.Font("Montserrat", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Tools");
        jPanel3.add(jLabel1);
        jLabel1.setBounds(240, 320, 67, 30);

        jLabel3.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(47, 46, 65));
        jLabel3.setText("Hello, Dev!");
        jPanel3.add(jLabel3);
        jLabel3.setBounds(20, 340, 144, 30);

        btnVoltarLogin.setBackground(new java.awt.Color(204, 204, 204));
        btnVoltarLogin.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        btnVoltarLogin.setForeground(new java.awt.Color(102, 102, 102));
        btnVoltarLogin.setText("Back");
        btnVoltarLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarLoginActionPerformed(evt);
            }
        });
        jPanel3.add(btnVoltarLogin);
        btnVoltarLogin.setBounds(340, 500, 83, 27);

        btnGoAtualizar.setBackground(new java.awt.Color(102, 51, 255));
        btnGoAtualizar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        btnGoAtualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnGoAtualizar.setText("Manage User");
        btnGoAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGoAtualizarActionPerformed(evt);
            }
        });
        jPanel3.add(btnGoAtualizar);
        btnGoAtualizar.setBounds(240, 380, 154, 38);

        btnSaindoWork.setBackground(new java.awt.Color(204, 204, 204));
        btnSaindoWork.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        btnSaindoWork.setForeground(new java.awt.Color(102, 102, 102));
        btnSaindoWork.setText("Exit");
        btnSaindoWork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaindoWorkActionPerformed(evt);
            }
        });
        jPanel3.add(btnSaindoWork);
        btnSaindoWork.setBounds(440, 500, 83, 27);

        jSeparator1.setBackground(new java.awt.Color(47, 46, 65));
        jSeparator1.setForeground(new java.awt.Color(47, 46, 65));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel3.add(jSeparator1);
        jSeparator1.setBounds(190, 110, 50, 480);

        jLabel4.setFont(new java.awt.Font("Montserrat", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Your E-mail");
        jPanel3.add(jLabel4);
        jLabel4.setBounds(240, 160, 144, 30);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/dev.png"))); // NOI18N
        jPanel3.add(jLabel5);
        jLabel5.setBounds(-10, 380, 220, 190);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarLoginActionPerformed
        TelaLogin telaLogin = new TelaLogin();
        telaLogin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarLoginActionPerformed

    private void btnGoAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoAtualizarActionPerformed
        TelaAtualizar telaAtualizar = new TelaAtualizar();
        telaAtualizar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGoAtualizarActionPerformed

    private void btnSaindoWorkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaindoWorkActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSaindoWorkActionPerformed

    public static void main(String args[]) {
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaWork.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaWork.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaWork.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaWork.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaWork().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGoAtualizar;
    private javax.swing.JButton btnSaindoWork;
    private javax.swing.JButton btnVoltarLogin;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}