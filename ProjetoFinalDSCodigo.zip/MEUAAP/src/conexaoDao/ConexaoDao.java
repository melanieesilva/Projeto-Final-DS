package conexaoDao;

import java.sql.*;

public class ConexaoDao {

    //Metodo para acessar a conexão com o Banco
    public static Connection conector() {
        java.sql.Connection conexao = null;

        //Chamando o driver de conexão
        String driver = "com.mysql.jdbc.Driver";

        //Atribuindo valores da url de conexão
        String url = "jdbc:mysql://localhost:3306/mydb";
        String user = "mel";
        String password = "78955123";

        //Tentando estabelecer a conexão
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            System.out.println("Não foi possível estabelecer uma conexão! Erro em: conexaoDao.ConexaoDao" + e);
            return null;
        }
    }
}
