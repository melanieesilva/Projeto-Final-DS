package conexaoDao;

import model.UsuarioModel;
import view.TelaLogin;
import java.sql.*;
import javax.swing.JOptionPane;
import model.ModelEntrada;
import view.TelaUsuarios;

public class LoginDao {

    private TelaLogin loginview;

    public LoginDao(TelaLogin loginview) {
        this.loginview = loginview;
    }

    public LoginDao() {
    }

    public void autenticar() throws SQLException {
        //Buscar um usuário
        //Verificar se existe no banco de dados
        //Se existir, direciona para a tela de perfil

        //Acessando os valores digitados no formulário de Login
        String nome = loginview.getNomeLogin().getText();
        String email = loginview.getEmailLogin().getText();

        //Atribuindo ao meu modelo/ou atribuindo ao model
        UsuarioModel objusuarioAutenticar = new UsuarioModel(nome, email);

        //Verificando se existe um registro
        Connection conexao = ConexaoDao.conector();
        UsuarioDao usuarioDao = new UsuarioDao(conexao);

        boolean existe;
        existe = usuarioDao.autenticarUsuario(objusuarioAutenticar);

        if (existe) {

            //Redireciona de Login para a TelaUsuarios - onde terá o display com nome e-mail do usuário
            TelaUsuarios telaUsuario = new TelaUsuarios();
            telaUsuario.setVisible(true);
            telaUsuario.setLocationRelativeTo(null);
            //Instancio uma classe modelo para receber os valores do Login e exportar para as labels da Tela de Usuário
            ModelEntrada entrada = new ModelEntrada();
            entrada.setNome(nome);
            entrada.setEmail(email);
            telaUsuario.exportarDados(entrada);
        } else {
            JOptionPane.showMessageDialog(loginview, "Nome ou e-mail inválidos");
        }

    }

}
